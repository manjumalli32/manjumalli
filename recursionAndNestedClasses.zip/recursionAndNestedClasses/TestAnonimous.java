package com.corejava.recursionAndNestedClasses;

@FunctionalInterface
public interface TestAnonimous {	
	
	public abstract void clikOnButton();

}
