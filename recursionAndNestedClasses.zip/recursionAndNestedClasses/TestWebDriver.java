package com.corejava.recursionAndNestedClasses;

public class TestWebDriver {

	public static void main(String[] args) {
		
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("DUmmy URL");
		
		WebDriver.Window w = driver.manage();
		w.maximize();
		
		driver.manage().maximize();
		

	
		
		
		
		
		
		
	}

}
