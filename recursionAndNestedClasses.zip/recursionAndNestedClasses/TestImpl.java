package com.corejava.recursionAndNestedClasses;

public class TestImpl implements TestAnonimous{

	
	public void clikOnButton() {
		System.out.println(" Implementation for ClickMethod...");
		
	}

}
