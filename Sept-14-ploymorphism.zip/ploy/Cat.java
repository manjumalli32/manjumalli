package com.corejava.ploy;

public class Cat extends Animal{
	
	public void eat()
	{
		System.out.println(" The Cat of the age "+age+" of the colour "+colour+" is eating..silently");
	}
	
	public void huntRat()
	{
		System.out.println(" The cat is really good in hunting the Rat,,,,");
	}

}
