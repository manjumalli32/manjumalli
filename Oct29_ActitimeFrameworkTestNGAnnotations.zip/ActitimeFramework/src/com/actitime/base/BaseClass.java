package com.actitime.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.google.common.io.Files;

public class BaseClass {
	
	public static WebDriver driver;

	
	@BeforeMethod(alwaysRun = true)
	public static void launchActiTimeApplication()
	{		
		launchBrowser();
		driver.get(getConfigData("url"));		

	}
	
	public static void launchBrowser()
	{
		String browser = getConfigData("browser");
		
		switch(browser)
		{
			case "firefox":
			{
				System.out.println(" Running the test cases using Firefox browser.....");
				System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
				driver = new FirefoxDriver();
			}
		
			case "chrome":
			{	
				System.out.println(" Running the test cases using chrome browser.....");
				System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
				driver = new ChromeDriver();
				break;
			}
			default :
			{
				System.out.println(" Browser not specified , using chrome as the default browser..");
				System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
				driver = new ChromeDriver();
				break;
			}
		}	
		
		driver.manage().window().maximize();
		// Applying implicit wait . it is applied only once where the driver is created and applicable through out the life cycle of the driver..
		// polling interval is 500 MS ( half second )
		String s = getConfigData("timeout"); // fetching the timeout from properties file and converting it to Long
		Long t = Long.parseLong(s);		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(t));
	}
	
	public static void launchApplication(String url)
	{
		launchBrowser();
		driver.get(url);
	}
	
	
	@AfterMethod(alwaysRun = true)
	public static void closeBrowser()	
	{
		driver.quit();
	}
	
	
	
	public static String getConfigData(String key) 
	{		
				
			Properties prop = new Properties();
				try {				
					File f = new File("./data/config.properties");	
					FileInputStream fio = new FileInputStream(f);
					prop.load(fio);					
				} catch (Exception e) {
					e.printStackTrace();
				}			
				String val = prop.getProperty(key);					
				return val;
				
				
	}
	
	
	public static void captureScreenShotOnFailure(String fileName) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;		
		// this method will return an object of File class
		File src = ts.getScreenshotAs(OutputType.FILE);
		
		// Creating an object of File class where we want to save  the screenshot
		File dest = new File("./results/screenshots/"+fileName+".png");
		
		// Copy the screenshot to the destination mentioned above
		Files.copy(src, dest);	
		
	}
	
	
	public static void writeResultsToFile(String testCaseName, String testCaseStatus) throws IOException
	{
		File f = new File("./results/results.txt");
		
		FileWriter fw = new FileWriter(f,true);
		
		fw.write(testCaseName+"-----"+testCaseStatus+"\n");
		
		
		fw.flush();
		fw.close();
		
	}
	
	
	public static void writeLogsToFile(String logMessage) throws IOException
	{
		File f = new File("./results/logs.txt");
		
		FileWriter fw = new FileWriter(f,true);
		
		fw.write(logMessage+"\n");
		
		
		fw.flush();
		fw.close();
		
	}
	
	
	public static String getLocatorDataFromExcel(String pageName, String elementName) throws IOException
	{
		String locator = "";
		
		File f = new File("./data/locatordata.xlsx");
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of the workbook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		// Creating the object of worksheet
		XSSFSheet ws= wb.getSheet("Sheet1");
		
		// getting the number of rows in the worksheet
		int rows = ws.getLastRowNum();
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && (elementName.equalsIgnoreCase(element)))
			{
				locator =  ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}			
		}		
		wb.close();		
		return locator;		
	}

	
	public static String getTestDataFromExcel(String pageName, String elementName) throws IOException
	{
		String testData = "";
		
		File f = new File("./data/testdata.xlsx");
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of the workbook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		// Creating the object of worksheet
		XSSFSheet ws= wb.getSheet("Sheet1");
		
		// getting the number of rows in the worksheet
		int rows = ws.getLastRowNum();
		
		for(int x=1;x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && (elementName.equalsIgnoreCase(element)))
			{
				testData =  ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}			
		}	
		wb.close();		
		return testData;		
	}

}


