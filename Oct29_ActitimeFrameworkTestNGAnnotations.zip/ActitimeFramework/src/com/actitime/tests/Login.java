package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass {
	
	

	
	//@Test(priority = 2) // Runs this test case as second priority after running first priority
	
	@Test
	public static void login_001() throws InterruptedException, IOException
	{
		writeLogsToFile("*************** Starting the test case Login_001*********************");		
		CommonUtils.loginToActitime();
		writeLogsToFile("Chcking for the logout link post login");
		boolean logoutLink = false;
		
		try {
			logoutLink = driver.findElement(By.xpath(getLocatorDataFromExcel("Home", "Logout_link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();			
		}
		
		Assert.assertTrue(logoutLink, "The logout link not seen Login_001 Failed");
		
		//Assert.assertFalse(logoutLink, "Expecting a condition to be false");
		
		/*
		 * Assert.assertEquals is used for comparing two variables for equality.
		int expEmpCount = 10;		
		int actEmpCount = 9;
		
		Assert.assertEquals(expEmpCount, actEmpCount,"the actual count of the emp is not matching ");
		*/
		writeLogsToFile("The logout link is displayed....login successFul");
		writeResultsToFile("Login_001", "Pass");	
		
		
	}
	
	
	//@Test(dependsOnMethods = { "login_001"}) // login_002 will only run if login_001 is Passed else it will skipped...
	
	//@Test(priority = 1) // Runs this test case as first priority
	
	@Test
	public static void login_002() throws InterruptedException, IOException
	{
		writeLogsToFile("*************** Starting the test case login_002*********************");		
		CommonUtils.loginToActitime();
		writeLogsToFile("Chcking for the logout link post login");
		boolean logoutLink = false;
		
		try {
			logoutLink = driver.findElement(By.xpath(getLocatorDataFromExcel("Home", "Logout_link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		Assert.assertTrue(logoutLink, "The Logout link not seen Login_002 Failed");
		
		writeLogsToFile("The logout link is displayed....login successFul");
		writeResultsToFile("login_002", "Pass");
		
		
		
		
		
		
	}



}
