package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Customer extends BaseClass {
	
	@Test
	public static void customer_001() throws InterruptedException, IOException
	{
		writeLogsToFile("*************** Starting the test case customer_001*********************");		
		CommonUtils.loginToActitime();
		writeLogsToFile("Chcking for the logout link post login");
		boolean logoutLink = false;
		
		try {
			logoutLink = driver.findElement(By.xpath(getLocatorDataFromExcel("Home", "Logout_link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		Assert.assertTrue(logoutLink, "The logout link not seen customer_001 Failed");
		
		writeLogsToFile("The logout link is displayed....login successFul");
		writeResultsToFile("customer_001", "Pass");
		
		
		
		
		
		
	}

}
