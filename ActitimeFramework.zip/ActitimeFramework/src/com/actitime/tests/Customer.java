package com.actitime.tests;

import com.actitime.base.BaseClass;

public class Customer extends BaseClass {

}
