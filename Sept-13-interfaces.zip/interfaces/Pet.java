package com.corejava.interfaces;

public interface Pet {
	
	void recognizeOwner();

}
