package com.corejava.interfaces;

public class Memal {
	
	public void walk()
	{
		System.out.println(" The Memal can walk");
	}

}
