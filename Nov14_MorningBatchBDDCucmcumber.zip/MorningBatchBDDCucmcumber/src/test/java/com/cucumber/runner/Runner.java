package com.cucumber.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
		
		tags = "", 
		features = "src/test/java/featurefiles/", 
		glue = "stepdeffiles")		

public class Runner  extends AbstractTestNGCucumberTests{

}
