package stepdeffiles;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login {
	
	WebDriver driver;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "./src/test/Utilities/chromedriver.exe");		
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));		
		driver.manage().window().maximize();		
	}
	
	@After
	public void tearDown()
	{
		driver.quit();
	}
	

@Given("As a user when I launch actitime application")
public void as_a_user_when_i_launch_actitime_application() {
	driver.get("https://demo.actitime.com/login.do");
}

@When("I enter valid username and valid password")
public void i_enter_valid_username_and_valid_password() {
	driver.findElement(By.id("username")).sendKeys("admin");
	driver.findElement(By.name("pwd")).sendKeys("manager");
}

@And("I click on LoginButton")
public void i_click_on_login_button() {
	driver.findElement(By.id("loginButton")).click();
}

@Then("I should be successfully logged into actitime")
public void i_should_be_successfully_logged_into_actitime() {
	boolean isDislayed = driver.findElement(By.id("logoutLink")).isDisplayed();
	Assert.assertTrue(isDislayed," User could not login  to Actitime...");
}

}
