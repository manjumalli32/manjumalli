package com.pageobect.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.pageobject.pages.HomePage;
import com.pageobject.pages.LoginPage;

public class LoginTest extends BaseClass{
	
	@Test
	public static void login_001()
	{
		LoginPage login = new LoginPage(driver);
			login.setUserName("admin");
			login.setPassword("manager");
			HomePage homepage = login.clickLoginButtonAndGoToHomePage(driver);
			
			//HomePage homepage = new HomePage(driver);
			boolean result = homepage.verifyLogoutLinkDisplay();
			
			Assert.assertTrue(result, "The Logout link not displayed!!");
			
		
	}
	
	@Test
	public static void login_002()
	{
		LoginPage login = new LoginPage(driver);
		login.setUserName("admin123");
		login.setPassword("manager");
		login.clickLoginButton();
		
		boolean result = login.errorMessageDisplayed();
		
		Assert.assertTrue(result, "The error message is not displayed!!");
	}
	
	
	

}
