package com.pageobject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.actitime.base.BaseClass;

public class LoginPage {
	
	private WebDriver driver;	
	

	public LoginPage(WebDriver driver)
	{			
		PageFactory.initElements(driver, this);
	}	
	
	@FindBy(id="username")
	private WebElement userName;
	
	@FindBy(name="pwd")
	private WebElement password;
	
	@FindBy(xpath="//a[@id='loginButton']")
	private WebElement loginButton;
	
	@FindBy(xpath = "//span[@class='errormsg'][contains(text(),'Username or Password ')]")
	private WebElement errorMessage;
	
	public void setUserName(String usernameData)
	{
		userName.sendKeys(usernameData);
		
	}
	
	public void setPassword(String passwordData)
	{
		password.sendKeys(passwordData);
	}
	
	public HomePage clickLoginButtonAndGoToHomePage(WebDriver driver)	
	{
		loginButton.click();
		HomePage home = new HomePage(driver);
		
		return home;
	}
	
	public void clickLoginButton()
	{
		loginButton.click();
	}
	
	public boolean errorMessageDisplayed()
	{
		boolean displayed = false;
		
		try {
			displayed = errorMessage.isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		
		return displayed;
		
	}
	
	
	
}
