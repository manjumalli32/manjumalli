package com.java.oops.inheritance;

public class Dog extends Memal {
	
	int age;
	String colour;
	
	public Dog()
	{
		super();
		System.out.println(" Inside the dog class default constructor...");
	}
	
	public Dog(int age, String colour, int mAge, String mColour, int aAge, String aColour)
	{
		super(aAge, aColour,mAge, mColour);		
		this.age = age;
		this.colour = colour;
	}
	
	public Dog(int age, String colour)
	{
		super(10,"Black");
		this.age = age;
		this.colour = colour;
	}
	
	public void bark()
	{
		System.out.println(" The Dog of the age "+age
				+" of the colour "+ colour + " is barking bow bow...");
	}
	
	public void eat()
	{
		System.out.println(" The Dogee of the age "+ age +
				" of the colour "+ colour+ " is eating" );
		
	}
	

}
