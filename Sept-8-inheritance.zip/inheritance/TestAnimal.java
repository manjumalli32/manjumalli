package com.java.oops.inheritance;

public class TestAnimal {

	public static void main(String[] args) {

		Dog d = new Dog();
		
		d.age = 5;
		d.colour = "White";
		
		System.out.println("=======================");
		
		Dog d1 = new Dog(2, "White");
		
		
		d1.eat();
		d1.sleep();
		d1.walk();
		d1.bark();
		System.out.println(d1.toString());		
		
		
		System.out.println("==============");
		
		Dog d2 = new Dog(2, "White", 5, "Black", 10, "Grey");
		
		d2.eat();
		d2.sleep();
		d2.walk();
		d2.bark();
		System.out.println(d2.toString());

	}

}
