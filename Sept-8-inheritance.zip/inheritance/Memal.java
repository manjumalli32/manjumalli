package com.java.oops.inheritance;

public class Memal extends Animal {
	
	int age;
	String colour;
	
	public Memal()
	{
		super();
		System.out.println(" Inside the Memal class default constructor...");
	}
	
	
	
	public Memal(int aAge, String aColour, int age, String colour) {
		
		super(aAge,aColour);
		this.age = age;
		this.colour = colour;
	}
	
	public Memal(int age, String colour) {
		
		super(15,"Grey");
		this.age = age;
		this.colour = colour;
	}



	public void walk()
	{
		System.out.println(" The memal of the age "+age
				+" of the colour "+ colour + " is walking");
	}

}
