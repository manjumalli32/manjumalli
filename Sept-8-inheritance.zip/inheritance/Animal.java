package com.java.oops.inheritance;

public class Animal {
	
	/*
	  
	  Tasks of Java Complier


		1. Checks for syntax
		2. Converts .java to .class
		3.Implicit Type casting for eg double d = 50; int x = 'a';
		4. Adds default constructor when not added by the programer
		5. Calls the super class constructor from the child class constructor
		
		Variable Masking or Variable hiding
		When we have the same instance variables both in parent and child class
		and on setting the values to the child class instance variables, 
		The values will only be set to the child class object and not cascade to the parent class object
	 */
	
		
	int age;
	
	public Animal(int age, String colour) {
		
		this.age = age;
		this.colour = colour;
	}

	String colour;
	
	public void eat()
	{
		System.out.println(" The animal of the age "+ age +
				" of the colour "+ colour+ " is eating" );
		
	}
	
	public void sleep()
	{
		System.out.println(" The animal of the age "+ age +
				" of the colour "+ colour+ " is sleeping" );
		
	}
	
	public Animal()
	{
		super();
		System.out.println(" Inside the Animal class default constructor...");
	}

}
