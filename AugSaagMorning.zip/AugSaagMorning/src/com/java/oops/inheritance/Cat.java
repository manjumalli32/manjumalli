package com.java.oops.inheritance;

public class Cat extends Memal{

	
	public void hunt() {
		System.out.println(" The cat is hunting....");
		
	}
	
	
	

}
