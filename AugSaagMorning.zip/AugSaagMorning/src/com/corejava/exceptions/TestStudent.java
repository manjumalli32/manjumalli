package com.corejava.exceptions;

public class TestStudent {

	public static void main(String[] args) throws InvalidAgeException {
	
		Student s = new Student();
		s.setName("Ramu");		
		s.setAge(-20);

	}

}
