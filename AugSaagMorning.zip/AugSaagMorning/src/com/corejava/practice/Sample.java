package com.corejava.practice;

public class Sample {
	
	final int length = 4;

	public static void main(String[] args) {
		System.out.println("Welcome to java by patil");
		
	}

}
