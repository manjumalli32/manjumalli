package com.corejava.practice;

public class TestAccess {

	public static void main(String[] args) {
		
		System.out.println(Aug8_MembersAndAccessControllers.personAge);
		Aug8_MembersAndAccessControllers.testStatic();
		System.out.println(Aug8_MembersAndAccessControllers.personAge);
		System.out.println(Aug8_MembersAndAccessControllers.y);
		
	}

}
