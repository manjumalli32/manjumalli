package com.corejava.package1;

import com.corejava.practice.Aug8_MembersAndAccessControllers;

public class TestAccessOutSidePackage {

	public static void main(String[] args) {
	System.out.println(Aug8_MembersAndAccessControllers.salary);

	}

}
