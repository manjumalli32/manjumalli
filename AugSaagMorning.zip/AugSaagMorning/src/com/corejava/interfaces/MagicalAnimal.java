package com.corejava.interfaces;

public interface MagicalAnimal {
	
	void hasMagicalPowers();

}
