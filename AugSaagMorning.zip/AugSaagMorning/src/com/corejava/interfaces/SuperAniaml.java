package com.corejava.interfaces;

public interface SuperAniaml {
	
	public abstract void showSuperPowersOfAnimal();

}
