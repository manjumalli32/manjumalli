package com.corejava.collections;

public class TestAnimal {

	public static void main(String[] args) {

		//Cat c = new Cat();
		//c.eat();
	//	c.drink();
		
		Animal a = new Tiger();
		
		a.drink();
		a.eat();
		

	}

}
