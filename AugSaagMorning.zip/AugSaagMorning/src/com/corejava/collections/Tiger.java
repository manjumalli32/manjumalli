package com.corejava.collections;

public class Tiger implements Animal{

	
	public void eat() {
	
		System.out.println(" The tiger is eating...");
	}

	
	public void drink() {
		System.out.println(" The tiger is drinking.......");
		
	}
	
	

}
