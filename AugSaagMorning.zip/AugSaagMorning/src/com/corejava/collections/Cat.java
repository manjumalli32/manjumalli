package com.corejava.collections;

public class Cat implements Animal{


	public void eat() {
		System.out.println("The cat is eating...");
		
	}


	public void drink() {
		System.out.println("The cat is drinking....");
		
	}

}
