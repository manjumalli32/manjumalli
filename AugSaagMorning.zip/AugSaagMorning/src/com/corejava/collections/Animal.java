package com.corejava.collections;

public interface Animal {
	
	public abstract void eat();	
	
	public abstract void drink();
	

}
