package com.corejava.ploy;

public class Tiger extends Animal{

	
	public void eat()
	{
		System.out.println(" The Tiger of the age "+age+
				" of the colour "+colour+" is eating & roaring....");
	}
	
	public void huntAnimals()
	{
		System.out.println(" The tiger silently attacks other aniimals for food....");
	}
	
	
	
		
	}


