package com.corejava.oops.poly2;

@FunctionalInterface
public interface Pet {
	
	void recognizeOwner();

}
