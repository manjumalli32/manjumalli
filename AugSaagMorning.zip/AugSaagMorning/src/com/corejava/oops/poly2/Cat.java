package com.corejava.oops.poly2;

public class Cat implements Animal {

	
	public void eat() {
		System.out.println(" The cat is eating....");
	}
	
	public void sleep() {
		System.out.println(" The cat is sleeping...");
	}

}
