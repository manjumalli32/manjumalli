package com.corejava.oops;

public class Bus extends Vehicle{
	
	public void stackLuggageOnTop()
	{
		System.out.println(" The bus of the color "+getColour() +
				"seating capacity of "+getSeatingCapacity() +
				 " Can have a luggage up to 500 kgs stacked on top..");
	}
	
	

}
