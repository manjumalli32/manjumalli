package com.corejava.oops.poly2;

public class Dog implements Animal{

	
	public void eat() {
		System.out.println(" The Dog is eating....");
		
	}

	
	public void sleep() {
		System.out.println(" The Dog is sleeping....");
		
	}
	
	public void bark()
	{
		System.out.println(" The dog is barking....");
	}
	
	

}
