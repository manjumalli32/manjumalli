package com.corejava.oops.poly2;

public class SmallDog implements Pet{

	
	public void recognizeOwner() {
		System.out.println(" The small dog can also recognize its owner....");
		
	}
	

}
