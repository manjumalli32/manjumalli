package com.corejava.oops.poly2;

public interface TestLambda1 {
	
	void sayHello();

}
