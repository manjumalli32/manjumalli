package com.corejava.oops.poly2;

@FunctionalInterface
public interface FuncTest {
	
	int addNumbers(int x , int y);

}
