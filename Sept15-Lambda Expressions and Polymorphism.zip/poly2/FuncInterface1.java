package com.corejava.oops.poly2;

public interface FuncInterface1 {
	
	void printNumberOfCharactersInString(String s);

}
